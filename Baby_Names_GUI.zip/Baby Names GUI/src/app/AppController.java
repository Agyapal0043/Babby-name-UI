package app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class AppController {
	
	private final String FILE_PREFIX = "babynamesranking";
	private final String FILE_PATH = "src/data/";
	
	@FXML TextField tf_name;
	@FXML TextField tf_year;
	@FXML TextField tf_gender;
	@FXML Label lbl_message;
	
	@FXML VBox panel_repeat;
	@FXML GridPane panel_main;
	
	@FXML
	public void initialize() {
		goToMainMenu(null);
	}
	
	@FXML
    private void submitClick(ActionEvent event)
    {
		String year = tf_year.getText();
		String name = tf_name.getText();
		String gender = tf_gender.getText();
		String message = "";
		
		int rank = -1;
		int isMale = -1;
		
		File fp = new File(FILE_PATH + FILE_PREFIX + year + ".txt");
		FileReader fr;
		try {
			fr = new FileReader(fp);
			BufferedReader br = new BufferedReader(fr);
			String line;
			
			// Read file line by line based on the year
			while((line = br.readLine()) != null) { 
				String[] lineData = line.split("\\s+");
				
				// Check for gender case
				if(gender.equalsIgnoreCase("m") || gender.equalsIgnoreCase("male")) {
					isMale = 1;
					if(lineData[1].equalsIgnoreCase(name)) {
						rank = Integer.parseInt(lineData[0]);
						break;
					}
				} else if(gender.equalsIgnoreCase("f") || gender.equalsIgnoreCase("female")) {
					isMale = 0;
					if(lineData[3].equalsIgnoreCase(name)) {
						rank = Integer.parseInt(lineData[0]);
						break;
					}
				}
			}
			
			// Based on whether the name was found or not, display appropriate message
			if(rank < 0) {
				message = "Could not find rank data for " + (isMale==1?"Boy":"Girl") + " name: " + name;
			} else {
				message = String.format("%s name %s is ranked #%s in %s year", isMale==1?"Boy":"Girl", name, rank, year);
			}
			
			fr.close();
		} catch (IOException e) {
			message = "Failed to load baby names data for year " + year;
		}
		
		lbl_message.setText(message);
		panel_repeat.setManaged(true);
		panel_repeat.setVisible(true);
    }
	
	@FXML
    private void goToMainMenu(ActionEvent event)
    {
		panel_repeat.setManaged(false);
		panel_repeat.setVisible(false);
    }
	
	@FXML
    private void exitClick(ActionEvent event)
    {
        Platform.exit();
    }
}
